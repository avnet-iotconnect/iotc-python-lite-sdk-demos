#!/bin/sh
set -e

mkdir -p /opt/demo/models
cp -f ./models/* /opt/demo/models/
if [ -f /opt/demo/models/model.tflite ] && [ ! -f /opt/demo/models/ds_cnn_s_quantized.tflite ]; then
  cp -f /opt/demo/models/model.tflite /opt/demo/models/ds_cnn_s_quantized.tflite
fi
if [ -f /opt/demo/models/ds_cnn_s_quantized.tflite ] && [ ! -f /opt/demo/models/model.tflite ]; then
  cp -f /opt/demo/models/ds_cnn_s_quantized.tflite /opt/demo/models/model.tflite
fi
echo "Installed model assets into /opt/demo/models"
