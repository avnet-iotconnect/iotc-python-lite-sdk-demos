#!/bin/bash

exec  /usr/sbin/shutdown now