"""
Vision AI Demo Pipeline Handler

This module manages GStreamer video pipelines for dual-camera AI inference demonstrations.
It handles camera detection, pipeline lifecycle, performance monitoring, and UI updates.

Key Components:
- Pipeline: Individual GStreamer pipeline wrapper with state management
- PipelineCtrl: Controller for dual-pipeline coordination with dedicated GStreamer thread
- Handler: Main event handler connecting UI to pipeline operations

Architecture:
- Main GTK thread: UI events and updates
- GStreamer thread: Dedicated thread for pipeline operations
- QProf thread: System performance monitoring
- Worker threads: Temperature and load sampling

Author: Avnet
Platform: QCS6490 Vision AI Kit
"""

import pathlib
import subprocess
import os
from vai.qprofile import QProfProcess
import gi
import threading
from gi.repository import Gdk
import json
import re
import fcntl

from .common import (
    APP_NAME,
    CAMERA,
    CLASSIFICATION,
    CPU_THERMAL_KEY,
    CPU_UTIL_KEY,
    DEFAULT_DUAL_WINDOW,
    DEFAULT_LEFT_WINDOW,
    DEPTH_SEGMENTATION,
    GPU_THERMAL_KEY,
    GPU_UTIL_KEY,
    MEM_THERMAL_KEY,
    MEM_UTIL_KEY,
    DSP_UTIL_KEY,
    NPU_THERMAL_KEY,
    OBJECT_DETECTION,
    POSE_DETECTION,
    SEGMENTATION,
    HW_SAMPLING_PERIOD_ms,
    AUTOMATIC_DEMO_SWITCH_s,
    QUIT_CLEANUP_DELAY_ms
)

from .temp_profile import get_cpu_gpu_mem_npu_temps

# Lock GTK and GStreamer versions to prevent API compatibility warnings
gi.require_version("Gtk", "3.0")
gi.require_version('Gst', '1.0') 

from gi.repository import GLib, Gtk, Gst

# Configure OpenCV to avoid conflicts with GStreamer
# MSMF (Media Foundation) can interfere with camera access
os.environ['OPENCV_VIDEOIO_PRIORITY_MSMF'] = '0'

# ============================================================================
# CONFIGURATION CONSTANTS
# ============================================================================

# Video display adjustment for proper aspect ratio
HEIGHT_OFFSET = 17

# Maximum window dimensions for video display
MAX_WINDOW_WIDTH = 1920 // 2  # Half of 1920 for dual display
MAX_WINDOW_HEIGHT = 720

# Camera detection timeouts
MIPI_CSI_CAMERA_SCAN_TIMEOUT = 5  # Seconds to wait for MIPI camera probe
CAMERA_SCAN_DELAY_ms = 3000       # Delay before scanning cameras on startup

# Shutdown delays
CLOSE_APPLICATION_DELAY = 2        # Seconds before final application exit
PIPELINE_THREAD_PAUSE_s = 0.1      # Sleep duration in pipeline operations

# Demo configurations
DUAL_WINDOW_DEMOS = ["add drop down items here if needed"]  # Demos requiring dual windows

# Pipeline health monitoring element
# This identity element with signal-handoffs enables pipeline monitoring
PIPELINE_HEALTH_SIGNAL = "identity signal-handoffs=true name=id"

# ============================================================================
# JSON FILE OPERATIONS
# ============================================================================

def safe_write_json(path, data):
    """
    Thread-safe JSON file writer using file locking.
    
    Acquires an exclusive lock before writing to prevent race conditions
    with concurrent readers or writers.
    
    Args:
        path (str): Path to the JSON file
        data (dict): Data to serialize and write
        
    Note:
        This complements safe_read_json from the main script, providing
        synchronized access to inference result files.
    """
    with open(path, "w") as f:
        fcntl.flock(f, fcntl.LOCK_EX)  # Acquire exclusive lock
        json.dump(data, f)
        fcntl.flock(f, fcntl.LOCK_UN)  # Release lock

'''
# ============================================================================
# INFERENCE RESULT PARSERS
# ============================================================================

def object_detection_parse(inference_string, pipeline_name):
    """
    Parse object detection inference results from GStreamer metadata.
    
    Extracts bounding boxes, class labels, and confidence scores from the
    structured inference string produced by qtiml* GStreamer elements.
    
    Format expected:
        bounding-boxes=(structure)<"label, id=(uint)X, confidence=(double)Y, 
        color=(uint)Z, rectangle=(float)<x, y, w, h>;">
    
    Args:
        inference_string (str): Raw inference metadata string from GStreamer
        pipeline_name (str): Pipeline identifier ("pipeline-0" or "pipeline-1")
        
    Writes:
        data_0.json or data_1.json with structure:
        {
            "DemoName": "Object Detection",
            "Number_Objects_Detected": N,
            "Object 0": {
                "ID": "Person",
                "Confidence": 0.95,
                "Rectangle": [x, y, w, h]
            },
            ...
        }
    """
    # Determine output file based on pipeline
    if pipeline_name == "pipeline-0":
        filename = "data_0.json"
    elif pipeline_name == "pipeline-1":
        filename = "data_1.json"
    
    # Initialize result structure
    result = {
        "DemoName": "Object Detection",
        "Number_Objects_Detected": 0
    }
    
    # Extract bounding boxes section from inference string
    bbox_section = re.search(r'bounding-boxes=\(structure\)<(.+?)>,\s*timestamp=', 
                            inference_string, re.DOTALL)
    if not bbox_section:
        return result
    
    bbox_text = bbox_section.group(1)
    
    # Pattern to match each detected object
    # Captures: label, confidence, and rectangle coordinates (x, y, width, height)
    object_pattern = (r'"([^,]+),\s*id=\(uint\)\d+,\s*confidence=\(double\)([\d.]+),'
                     r'\s*color=\(uint\)\d+,\s*rectangle=\(float\)<\s*([\d.]+),\s*'
                     r'([\d.]+),\s*([\d.]+),\s*([\d.]+)\s*>;')
    
    object_matches = re.finditer(object_pattern, bbox_text)
    
    object_count = 0
    for match in object_matches:
        # Extract detection parameters
        label = match.group(1).strip()
        confidence = float(match.group(2))
        rect_x = float(match.group(3))
        rect_y = float(match.group(4))
        rect_w = float(match.group(5))
        rect_h = float(match.group(6))
        
        # Capitalize label for consistent formatting
        capitalized_label = label.capitalize()
        
        # Add object to results
        object_key = f"Object {object_count}"
        result[object_key] = {
            "ID": capitalized_label,
            "Confidence": confidence,
            "Rectangle": [rect_x, rect_y, rect_w, rect_h]
        }
        object_count += 1
    
    result["Number_Objects_Detected"] = object_count
    safe_write_json(filename, result)


def pose_estimation_parse(inference_string, pipeline_name):
    """
    Parse pose estimation inference results from GStreamer metadata.
    
    Extracts 17 keypoints (body joints) with positions, confidences, and
    skeletal connections for human pose estimation.
    
    Keypoints include: nose, eyes, ears, shoulders, elbows, wrists, hips,
    knees, ankles (standard COCO pose format).
    
    Args:
        inference_string (str): Raw inference metadata string from GStreamer
        pipeline_name (str): Pipeline identifier ("pipeline-0" or "pipeline-1")
        
    Writes:
        data_0.json or data_1.json with structure:
        {
            "DemoName": "Pose Estimation",
            "PoseConfidence": 0.92,
            "Nose": {
                "Confidence": 98.5,
                "X": 0.5,
                "Y": 0.3,
                "Connections": ["Left Eye", "Right Eye"]
            },
            ...
        }
    """
    # Determine output file based on pipeline
    if pipeline_name == "pipeline-0":
        filename = "data_0.json"
    elif pipeline_name == "pipeline-1":
        filename = "data_1.json"
    
    # Initialize result structure
    result = {
        "DemoName": "Pose Estimation",
        "PoseConfidence": 0.0
    }
    
    # Extract overall pose confidence
    pose_conf_match = re.search(r'pose,\s*id=\(uint\)\d+,\s*confidence=\(double\)([\d.]+)', 
                                inference_string)
    if pose_conf_match:
        result["PoseConfidence"] = float(pose_conf_match.group(1))
    else:
        return  # No valid pose detected
    
    # Extract keypoints section
    keypoints_section = re.search(r'keypoints=\(structure\)<(.+?)>,\s*connections=', 
                                 inference_string, re.DOTALL)
    if not keypoints_section:
        return
    
    keypoints_text = keypoints_section.group(1)
    
    # Pattern to match each keypoint
    # Captures: name, confidence, x coordinate, y coordinate
    keypoint_pattern = r'"([^"]+),\s*confidence=\(double\)([\d.]+),\s*x=\(double\)([\d.]+),\s*y=\(double\)([\d.]+)'
    keypoint_matches = re.finditer(keypoint_pattern, keypoints_text)
    
    # Process each keypoint
    for match in keypoint_matches:
        # Clean up keypoint name (replace dots with spaces, title case)
        name = match.group(1).replace('.', ' ').title()
        confidence = float(match.group(2))
        x = float(match.group(3))
        y = float(match.group(4))

        # Store keypoint data (confidence as percentage)
        result[name] = {
            "Confidence": 100 * confidence,
            "X": x,
            "Y": y,
            "Connections": []  # Will be populated below
        }
    
    # Extract skeletal connections (bones connecting keypoints)
    connections_section = re.search(r'connections=\(string\)<(.+?)>;', 
                                   inference_string, re.DOTALL)
    if connections_section:
        connections_text = connections_section.group(1)
        
        # Pattern to match connection pairs
        connection_pattern = r'<\s*\(string\)"([^"]+)",\s*\(string\)"([^"]+)"\s*>'
        connection_matches = re.finditer(connection_pattern, connections_text)
        
        # Build bidirectional connection graph
        for match in connection_matches:
            keypoint1 = match.group(1).replace('.', ' ').title()
            keypoint2 = match.group(2).replace('.', ' ').title()

            # Add connection to first keypoint
            if keypoint1 in result:
                if keypoint2 not in result[keypoint1]["Connections"]:
                    result[keypoint1]["Connections"].append(keypoint2)
            
            # Add connection to second keypoint (bidirectional)
            if keypoint2 in result:
                if keypoint1 not in result[keypoint2]["Connections"]:
                    result[keypoint2]["Connections"].append(keypoint1)
    
    safe_write_json(filename, result)


def image_classification_parse(inference_string, pipeline_name):
    """
    Parse image classification inference results from GStreamer metadata.
    
    Extracts top-N class predictions with labels and confidence scores,
    typically from ImageNet or custom classification models.
    
    Args:
        inference_string (str): Raw inference metadata string from GStreamer
        pipeline_name (str): Pipeline identifier ("pipeline-0" or "pipeline-1")
        
    Writes:
        data_0.json or data_1.json with structure:
        {
            "DemoName": "Image Classification",
            "Classification 0": {
                "ID": "Golden Retriever",
                "Confidence": 0.94
            },
            "Classification 1": {
                "ID": "Labrador",
                "Confidence": 0.03
            },
            ...
        }
    """
    # Determine output file based on pipeline
    if pipeline_name == "pipeline-0":
        filename = "data_0.json"
    elif pipeline_name == "pipeline-1":
        filename = "data_1.json"
    
    # Initialize result structure
    result = {
        "DemoName": "Image Classification"
    }
    
    # Extract labels section from inference string
    labels_section = re.search(r'labels=\(structure\)<(.+?)>,\s*timestamp=', 
                              inference_string, re.DOTALL)
    if not labels_section:
        return result
    
    labels_text = labels_section.group(1)
    
    # Pattern to extract each classification
    # Captures: label, id, confidence, color
    classification_pattern = (r'"([^,]+),\s*id=\(uint\)\d+,\s*confidence=\(double\)'
                            r'([\d.]+),\s*color=\(uint\)\d+;')
    
    classification_matches = re.finditer(classification_pattern, labels_text)
    
    classification_count = 0
    for match in classification_matches:
        label = match.group(1).strip()
        confidence = float(match.group(2))
        
        # Capitalize label for consistent formatting
        capitalized_label = label.capitalize()
        
        # Add classification to results
        classification_key = f"Classification {classification_count}"
        result[classification_key] = {
            "ID": capitalized_label,
            "Confidence": confidence
        }
        
        classification_count += 1
    
    safe_write_json(filename, result)
'''

# ============================================================================
# INFERENCE RESULT PARSERS
# ============================================================================

def object_detection_parse(inference_string, pipeline_name):
    """
    Parse object detection inference results from GStreamer metadata.
    
    Extracts bounding boxes, class labels, and confidence scores from the
    structured inference string produced by qtiml* GStreamer elements.
    
    Format expected:
        bounding-boxes=(structure)<"label, id=(uint)X, confidence=(double)Y, 
        color=(uint)Z, rectangle=(float)<x, y, w, h>;">
    
    Args:
        inference_string (str): Raw inference metadata string from GStreamer
        pipeline_name (str): Pipeline identifier ("pipeline-0" or "pipeline-1")
        
    Writes:
        data_0.json or data_1.json with structure:
        {
            "DemoName": "Object Detection",
            "Number_Objects_Detected": N,
            "Object 0": {
                "ID": "Person",
                "Confidence": 0.95,
                "Rectangle": [x, y, w, h]
            },
            ...
        }
    """
    # Determine output file based on pipeline
    if pipeline_name == "pipeline-0":
        filename = "data_0.json"
    elif pipeline_name == "pipeline-1":
        filename = "data_1.json"
    
    # Initialize result structure
    result = {
        "DemoName": "Object Detection",
        "Number_Objects_Detected": 0
    }
    
    # Extract bounding boxes section from inference string
    bbox_section = re.search(r'bounding-boxes=\(structure\)<(.+?)>,\s*timestamp=', 
                            inference_string, re.DOTALL)
    if not bbox_section:
        return result
    
    bbox_text = bbox_section.group(1)
    
    # Pattern to match each detected object
    # Captures: label, confidence, and rectangle coordinates (x, y, width, height)
    object_pattern = (r'"([^,]+),\s*id=\(uint\)\d+,\s*confidence=\(double\)([\d.]+),'
                     r'\s*color=\(uint\)\d+,\s*rectangle=\(float\)<\s*([\d.]+),\s*'
                     r'([\d.]+),\s*([\d.]+),\s*([\d.]+)\s*>;')
    
    object_matches = re.finditer(object_pattern, bbox_text)
    
    object_count = 0
    for match in object_matches:
        # Extract detection parameters
        label = match.group(1).strip()
        confidence = round(float(match.group(2)), 2)
        rect_x = round(float(match.group(3)), 2)
        rect_y = round(float(match.group(4)), 2)
        rect_w = round(float(match.group(5)), 2)
        rect_h = round(float(match.group(6)), 2)
        
        # Capitalize label for consistent formatting
        capitalized_label = label.capitalize()
        
        # Add object to results
        object_key = f"Object {object_count}"
        result[object_key] = {
            "ID": capitalized_label,
            "Confidence": confidence,
            "Rectangle": [rect_x, rect_y, rect_w, rect_h]
        }
        object_count += 1
    
    result["Number_Objects_Detected"] = object_count
    safe_write_json(filename, result)


def pose_estimation_parse(inference_string, pipeline_name):
    """
    Parse pose estimation inference results from GStreamer metadata.
    
    Extracts 17 keypoints (body joints) with positions, confidences, and
    skeletal connections for human pose estimation.
    
    Keypoints include: nose, eyes, ears, shoulders, elbows, wrists, hips,
    knees, ankles (standard COCO pose format).
    
    Args:
        inference_string (str): Raw inference metadata string from GStreamer
        pipeline_name (str): Pipeline identifier ("pipeline-0" or "pipeline-1")
        
    Writes:
        data_0.json or data_1.json with structure:
        {
            "DemoName": "Pose Estimation",
            "PoseConfidence": 0.92,
            "Nose": {
                "Confidence": 98.5,
                "X": 0.5,
                "Y": 0.3,
                "Connections": ["Left Eye", "Right Eye"]
            },
            ...
        }
    """
    # Determine output file based on pipeline
    if pipeline_name == "pipeline-0":
        filename = "data_0.json"
    elif pipeline_name == "pipeline-1":
        filename = "data_1.json"
    
    # Initialize result structure
    result = {
        "DemoName": "Pose Estimation",
        "PoseConfidence": 0.0
    }
    
    # Extract overall pose confidence
    pose_conf_match = re.search(r'pose,\s*id=\(uint\)\d+,\s*confidence=\(double\)([\d.]+)', 
                                inference_string)
    if pose_conf_match:
        result["PoseConfidence"] = round(float(pose_conf_match.group(1)), 4)
    else:
        return  # No valid pose detected
    
    # Extract keypoints section
    keypoints_section = re.search(r'keypoints=\(structure\)<(.+?)>,\s*connections=', 
                                 inference_string, re.DOTALL)
    if not keypoints_section:
        return
    
    keypoints_text = keypoints_section.group(1)
    
    # Pattern to match each keypoint
    # Captures: name, confidence, x coordinate, y coordinate
    keypoint_pattern = r'"([^"]+),\s*confidence=\(double\)([\d.]+),\s*x=\(double\)([\d.]+),\s*y=\(double\)([\d.]+)'
    keypoint_matches = re.finditer(keypoint_pattern, keypoints_text)
    
    # Process each keypoint
    for match in keypoint_matches:
        # Clean up keypoint name (replace dots with spaces, title case)
        name = match.group(1).replace('.', ' ').title()
        confidence = round(100 * float(match.group(2)), 2)
        x = round(float(match.group(3)), 2)
        y = round(float(match.group(4)), 2)

        # Store keypoint data (confidence as percentage)
        result[name] = {
            "Confidence": confidence,
            "X": x,
            "Y": y,
            "Connections": []  # Will be populated below
        }
    
    # Extract skeletal connections (bones connecting keypoints)
    connections_section = re.search(r'connections=\(string\)<(.+?)>;', 
                                   inference_string, re.DOTALL)
    if connections_section:
        connections_text = connections_section.group(1)
        
        # Pattern to match connection pairs
        connection_pattern = r'<\s*\(string\)"([^"]+)",\s*\(string\)"([^"]+)"\s*>'
        connection_matches = re.finditer(connection_pattern, connections_text)
        
        # Build bidirectional connection graph
        for match in connection_matches:
            keypoint1 = match.group(1).replace('.', ' ').title()
            keypoint2 = match.group(2).replace('.', ' ').title()

            # Add connection to first keypoint
            if keypoint1 in result:
                if keypoint2 not in result[keypoint1]["Connections"]:
                    result[keypoint1]["Connections"].append(keypoint2)
            
            # Add connection to second keypoint (bidirectional)
            if keypoint2 in result:
                if keypoint1 not in result[keypoint2]["Connections"]:
                    result[keypoint2]["Connections"].append(keypoint1)
    
    safe_write_json(filename, result)


def image_classification_parse(inference_string, pipeline_name):
    """
    Parse image classification inference results from GStreamer metadata.
    
    Extracts top-N class predictions with labels and confidence scores,
    typically from ImageNet or custom classification models.
    
    Args:
        inference_string (str): Raw inference metadata string from GStreamer
        pipeline_name (str): Pipeline identifier ("pipeline-0" or "pipeline-1")
        
    Writes:
        data_0.json or data_1.json with structure:
        {
            "DemoName": "Image Classification",
            "Classification 0": {
                "ID": "Golden Retriever",
                "Confidence": 0.94
            },
            "Classification 1": {
                "ID": "Labrador",
                "Confidence": 0.03
            },
            ...
        }
    """
    # Determine output file based on pipeline
    if pipeline_name == "pipeline-0":
        filename = "data_0.json"
    elif pipeline_name == "pipeline-1":
        filename = "data_1.json"
    
    # Initialize result structure
    result = {
        "DemoName": "Image Classification"
    }
    
    # Extract labels section from inference string
    labels_section = re.search(r'labels=\(structure\)<(.+?)>,\s*timestamp=', 
                              inference_string, re.DOTALL)
    if not labels_section:
        return result
    
    labels_text = labels_section.group(1)
    
    # Pattern to extract each classification
    # Captures: label, id, confidence, color
    classification_pattern = (r'"([^,]+),\s*id=\(uint\)\d+,\s*confidence=\(double\)'
                            r'([\d.]+),\s*color=\(uint\)\d+;')
    
    classification_matches = re.finditer(classification_pattern, labels_text)
    
    classification_count = 0
    for match in classification_matches:
        label = match.group(1).strip()
        confidence = round(float(match.group(2)), 2)
        
        # Capitalize label for consistent formatting
        capitalized_label = label.capitalize()
        
        # Add classification to results
        classification_key = f"Classification {classification_count}"
        result[classification_key] = {
            "ID": capitalized_label,
            "Confidence": confidence
        }
        
        classification_count += 1
    
    safe_write_json(filename, result)


# ============================================================================
# PIPELINE CLASS
# ============================================================================

class Pipeline:
    """
    Wrapper for individual GStreamer pipeline with lifecycle management.
    
    This class encapsulates a single GStreamer pipeline, handling state
    transitions, message processing, and UI integration. Each pipeline
    operates on the dedicated GStreamer thread to avoid blocking the UI.
    
    State Management:
    - Pipeline states: NULL -> READY -> PAUSED -> PLAYING
    - Stopping is asynchronous: set to NULL, wait for state change, cleanup
    - The is_stopping flag prevents race conditions during shutdown
    
    Attributes:
        name (str): Pipeline identifier (e.g., "pipeline-0")
        main_loop (GLib.MainLoop): GStreamer thread's main loop
        main_context (GLib.MainContext): GStreamer thread's context
        pipeline (Gst.Pipeline): The actual GStreamer pipeline object
        videosink (Gtk.Box): GTK container for video widget
        is_stopping (bool): Flag indicating shutdown in progress
        _on_stopped_callback (callable): Function to call after stop completes
    """
    
    def __init__(self, name, main_loop, main_context):
        """
        Initialize pipeline wrapper.
        
        Args:
            name (str): Pipeline identifier
            main_loop (GLib.MainLoop): GStreamer thread's main loop
            main_context (GLib.MainContext): GStreamer thread's context
        """
        self.name = name
        self.main_loop = main_loop
        self.main_context = main_context
        self.pipeline = None
        self.videosink = None
        self.is_stopping = False

    def set_sink(self, sink):
        """
        Associate a GTK container with this pipeline for video display.
        
        Args:
            sink (Gtk.Box): GTK container to hold video widget
            
        Returns:
            int: GLib.SOURCE_REMOVE to indicate one-time execution
        """
        self.videosink = sink
        return GLib.SOURCE_REMOVE

    def start(self, command):
        """
        Parse, configure, and start the GStreamer pipeline.
        
        This method:
        1. Parses the pipeline string
        2. Configures bus for message handling
        3. Sets queue properties for low latency
        4. Links video output to GTK widget (if present)
        5. Connects ML inference output sink (if present)
        6. Starts pipeline playback
        
        Args:
            command (str): GStreamer pipeline description string
            
        Returns:
            int: GLib.SOURCE_REMOVE to indicate one-time execution
        """
        # Prevent starting if pipeline already exists
        if self.pipeline:
            print(f"[{self.name}] Warning: Pipeline already running. Stop it first.")
            return GLib.SOURCE_REMOVE

        print(f"[{self.name}] Assigning command and starting stream...")
        
        # Parse pipeline string into GStreamer elements
        self.pipeline = Gst.parse_launch(command)

        # Set up message bus for pipeline events
        bus = self.pipeline.get_bus()
        bus.add_signal_watch()
        bus.connect("message", self.on_message)
        self.pipeline.set_auto_flush_bus(True)
        
        # Configure queue elements for low-latency operation
        self.pipeline.iterate_elements().foreach(self._set_queue_properties)

        # Connect video output to GTK widget if present
        videosink_element = self.pipeline.get_by_name("videosink")
        if videosink_element:
            videosink_widget = videosink_element.props.video_sink.props.widget
            # Schedule linking on GTK main thread
            # This will trigger pipeline playback once widget is attached
            GLib.idle_add(self._link_stream_to_gtk, videosink_widget)
        else:
            print(f"[{self.name}] Error: no 'videosink' element found in the pipeline.")
            self.pipeline.set_state(Gst.State.NULL)
            self.pipeline = None

        # Connect ML inference output sink if present
        appsink_element = self.pipeline.get_by_name("ml-appsink")
        if appsink_element:
            print(f"[{self.name}] Found appsink 'ml-appsink'. Connecting to new-sample signal.")
            appsink_element.set_property("emit-signals", True)
            appsink_element.connect("new-sample", self.on_new_sample_from_sink)
            # No video widget needed, start playing immediately
            # Schedule on GStreamer thread context
            GLib.idle_add(self._set_pipeline_to_playing, context=self.main_context)
        else:
            print(f"[{self.name}] Error: no 'ml-appsink' element found in the pipeline.")

        return GLib.SOURCE_REMOVE

    def stop(self, on_stopped_callback=None):
        """
        Stop and clean up the GStreamer pipeline asynchronously.
        
        This method initiates an asynchronous shutdown sequence:
        1. Set stopping flag to prevent race conditions
        2. Request state change to NULL
        3. Wait for STATE_CHANGED message
        4. Finalize cleanup in _finalize_stop()
        5. Call callback if provided
        
        Multiple stop requests are handled gracefully by updating the
        callback to the most recent one.
        
        Args:
            on_stopped_callback (callable, optional): Function to call after
                pipeline is fully stopped and cleaned up
            
        Returns:
            int: GLib.SOURCE_REMOVE to indicate one-time execution
        """
        # Already stopped - just execute callback
        if not self.pipeline:
            if on_stopped_callback:
                GLib.idle_add(on_stopped_callback)
            return GLib.SOURCE_REMOVE

        # Update callback to most recent one
        self._on_stopped_callback = on_stopped_callback

        # Stop already in progress - callback updated, nothing more to do
        if self.is_stopping:
            print(f"[{self.name}] Stop already in progress. Updating callback.")
            return GLib.SOURCE_REMOVE

        # Initiate new stop sequence
        print(f"[{self.name}] Stopping pipeline...")
        self.is_stopping = True
        
        # Request state change to NULL
        ret = self.pipeline.set_state(Gst.State.NULL)
        
        if ret == Gst.StateChangeReturn.ASYNC:
            # State change is asynchronous - wait for STATE_CHANGED message
            print(f"[{self.name}] Waiting for pipeline to stop asynchronously...")
        else:
            # State change completed immediately or failed
            # Finalize now to prevent stuck state
            print(f"[{self.name}] Pipeline stop was not async (ret={ret.value_nick}). "
                  f"Finalizing immediately.")
            self._finalize_stop()

        return GLib.SOURCE_REMOVE

    def _finalize_stop(self):
        """
        Perform actual resource cleanup after pipeline reaches NULL state.
        
        This method is called after the pipeline has transitioned to NULL
        state, either synchronously or asynchronously. It cleans up all
        resources and calls the completion callback if provided.
        
        Cleanup sequence:
        1. Clear video widget from UI container
        2. Remove bus signal watch
        3. Clear pipeline reference
        4. Reset stopping flag
        5. Execute completion callback
        """
        print(f"[{self.name}] Finalizing pipeline stop.")
        
        if not self.pipeline:
            return
 
        # Schedule UI cleanup on GTK main thread
        GLib.idle_add(self._clear_gtkbox)

        # Clean up GStreamer bus
        bus = self.pipeline.get_bus()
        if bus:
            bus.remove_signal_watch()
        
        # Clear pipeline reference
        self.pipeline = None
        self.is_stopping = False
        print(f"[{self.name}] Pipeline stopped and cleaned up.")

        # Execute completion callback if provided
        if hasattr(self, '_on_stopped_callback') and self._on_stopped_callback:
            GLib.idle_add(self._on_stopped_callback)
            self._on_stopped_callback = None

    def on_message(self, bus, message):
        """
        Handle GStreamer bus messages.
        
        Processes various message types from the pipeline:
        - EOS: End of stream
        - ERROR: Pipeline errors
        - STATE_CHANGED: State transitions (used for stop coordination)
        - ELEMENT: Custom messages from elements (e.g., inference results)
        
        Args:
            bus (Gst.Bus): Message bus
            message (Gst.Message): Message object
            
        Returns:
            bool: True to continue receiving messages
        """
        t = message.type

        if t == Gst.MessageType.EOS:
            print(f"[{self.name}] Got EOS from sink pipeline")

        elif t == Gst.MessageType.ERROR:
            err, debug = message.parse_error()
            print(f"[{self.name}][{message.src.get_name()}] Error: {err.message}")

        elif t == Gst.MessageType.STATE_CHANGED:
            # Only process messages from the pipeline itself
            if message.src == self.pipeline:
                old_state, new_state, pending_state = message.parse_state_changed()
                print(f"[{self.name}] Pipeline state changed from "
                      f"{old_state.value_nick} to {new_state.value_nick}.")
                
                # Complete stop sequence when NULL state is reached
                if self.is_stopping and new_state == Gst.State.NULL:
                    self._finalize_stop()  # Runs on GStreamer thread
        
        elif t == Gst.MessageType.ELEMENT:
            # Custom element messages (e.g., inference results)
            structure = message.get_structure()
            if structure and structure.has_name("qtias-private-data"):
                # qtimlv* elements use "qtias-private-data" structure name
                if structure.has_field("data"):
                    inference_data_str = structure.get_value("data")
                    # Raw inference data (typically JSON string)
                    print(f"[{self.name}] Inference Result: {inference_data_str}")

        return True
    
    def on_new_sample_from_sink(self, sink):
        """
        Callback for appsink's 'new-sample' signal.
        
        This callback receives inference results from the ML processing
        pipeline through an appsink element. It extracts the data, determines
        the inference type (pose, object detection, classification), and
        dispatches to the appropriate parser.
        
        Args:
            sink (Gst.Element): The appsink element emitting the signal
            
        Returns:
            Gst.FlowReturn: OK if successful, ERROR otherwise
        """
        # Pull sample from appsink
        sample = sink.emit("pull-sample")
        if sample:
            buf = sample.get_buffer()
            if buf:
                # Map buffer to read its contents
                result, map_info = buf.map(Gst.MapFlags.READ)
                if result:
                    try:
                        # Decode buffer data (UTF-8 string with inference results)
                        inference_data_str = map_info.data.tobytes().decode("utf-8").replace("\\","")
                        
                        # Dispatch to appropriate parser based on inference type
                        if "PoseEstimation" in inference_data_str:
                            pose_estimation_parse(inference_data_str, self.name)
                        elif "ObjectDetection" in inference_data_str:
                            object_detection_parse(inference_data_str, self.name)
                        elif "ImageClassification" in inference_data_str:
                            image_classification_parse(inference_data_str, self.name)
                        else:
                            # Unknown inference type
                            print(f"[{self.name}] Inference Result (from appsink): "
                                  f"{inference_data_str}")
                    finally:
                        # Always unmap buffer
                        buf.unmap(map_info)
            return Gst.FlowReturn.OK
        
        return Gst.FlowReturn.ERROR
        
    def _link_stream_to_gtk(self, videosink_widget):
        """
        Attach video widget to GTK container.
        
        This method runs on the GTK main thread and adds the GStreamer
        video widget to the UI container, then triggers pipeline playback.
        
        Args:
            videosink_widget (Gtk.Widget): Video display widget from gtksink
            
        Returns:
            int: GLib.SOURCE_REMOVE to indicate one-time execution
        """
        self.videosink.pack_start(videosink_widget, True, True, 0)
        videosink_widget.show()
        
        # Now that widget is in UI, start pipeline playback
        # Schedule on GStreamer thread context
        GLib.idle_add(self._set_pipeline_to_playing, context=self.main_context)
        return GLib.SOURCE_REMOVE

    def _set_pipeline_to_playing(self):
        """
        Set pipeline to PLAYING state.
        
        This method should be called from the GStreamer thread after
        the video widget has been added to the UI.
        
        Returns:
            int: GLib.SOURCE_REMOVE to indicate one-time execution
        """
        if self.pipeline:
            print(f"[{self.name}] UI sink ready. Setting pipeline to PLAYING.")
            self.pipeline.set_state(Gst.State.PLAYING)
        return GLib.SOURCE_REMOVE

    def _clear_gtkbox(self):
        """
        Remove all children from video sink container.
        
        Cleans up the GTK container by removing the video widget.
        Must run on GTK main thread.
        
        Returns:
            int: GLib.SOURCE_REMOVE to indicate one-time execution
        """
        for child in self.videosink.get_children():
            self.videosink.remove(child)
        return GLib.SOURCE_REMOVE

    def _set_queue_properties(self, element):
        """
        Configure queue elements for low-latency streaming.
        
        Sets buffer limits on queue elements to minimize latency at the
        cost of potentially dropping frames under load.
        
        Configuration:
        - max-size-buffers: 10 frames
        - max-size-bytes: 1 MB
        - max-size-time: 100ms
        - leaky: 2 (drop oldest buffers when full)
        
        Args:
            element (Gst.Element): Pipeline element to potentially configure
        """
        if element.get_factory().get_name().startswith('queue'):
            element.set_property("max-size-buffers", 10)
            element.set_property("max-size-bytes", 1 * 1024 * 1024)  # 1 MB
            element.set_property("max-size-time", 0.1 * Gst.SECOND)  # 0.1 second
            element.set_property("leaky", 2)  # Drop old buffers

    def _check_pipeline_state(self):
        """
        Check and print the current pipeline state.
        
        Utility method for debugging pipeline state transitions.
        Gets the current state immediately without blocking.
        
        Returns:
            Gst.State: Current pipeline state, or None if query failed
        """
        state_return, state, pending = self.pipeline.get_state(Gst.CLOCK_TIME_NONE)
        if state_return == Gst.StateChangeReturn.SUCCESS:
            return state
        else:
            print(f"Failed to get pipeline state. Return: {state_return}")
            return state


# ============================================================================
# PIPELINE CONTROLLER CLASS
# ============================================================================

class PipelineCtrl:
    """
    Controller for dual GStreamer pipelines with dedicated thread.
    
    This class manages two independent pipelines (one per camera) and
    provides a dedicated GLib main loop running in a separate thread
    for GStreamer operations. This architecture prevents GStreamer
    blocking from affecting the GTK UI thread.
    
    Thread Architecture:
    - GTK main thread: UI events and rendering
    - GStreamer thread: Pipeline operations and state management
    - Communication: GLib.idle_add with context parameter
    
    Attributes:
        gstreamer_main_loop (GLib.MainLoop): Main loop for GStreamer thread
        gstreamer_main_context (GLib.MainContext): Context for GStreamer thread
        gst_thread_started (Event): Signals GStreamer thread initialization
        gst_thread (Thread): The GStreamer thread object
        Pipeline0 (Pipeline): First camera pipeline
        Pipeline1 (Pipeline): Second camera pipeline
    """
    
    def __init__(self):
        """
        Initialize pipeline controller and start GStreamer thread.
        
        Creates a dedicated thread with its own GLib main loop for
        GStreamer operations, then initializes two pipeline objects.
        
        Raises:
            RuntimeError: If GStreamer thread fails to initialize within timeout
        """
        self.gstreamer_main_loop = None
        self.gstreamer_main_context = None
        self.gst_thread_started = threading.Event()

        # Start dedicated GStreamer thread
        self.gst_thread = threading.Thread(
            target=self._gstreamer_thread_main, 
            name="GstLoopThread"
        )
        self.gst_thread.start()

        # Wait for GStreamer loop initialization (max 2 seconds)
        self.gst_thread_started.wait(timeout=2)
        if not self.gstreamer_main_loop:
            raise RuntimeError("GStreamer thread failed to initialize.")

        # Create pipeline objects
        self.Pipeline0 = Pipeline("pipeline-0", self.gstreamer_main_loop, 
                                 self.gstreamer_main_context)
        self.Pipeline1 = Pipeline("pipeline-1", self.gstreamer_main_loop, 
                                 self.gstreamer_main_context)

    def _gstreamer_thread_main(self):
        """
        Main function for dedicated GStreamer thread.
        
        This function runs in a separate thread and:
        1. Creates a new GMainContext for this thread
        2. Sets it as the thread-default context
        3. Creates a GLib.MainLoop using this context
        4. Runs the main loop until quit is called
        5. Cleans up the context on exit
        
        The thread-default context ensures all GLib operations scheduled
        from this thread or with this context use the GStreamer thread's
        main loop rather than the GTK main thread's loop.
        """
        # Create new GMainContext for this thread
        self.gstreamer_main_context = GLib.MainContext.new()

        # Set as thread-default (all GLib operations use this context)
        self.gstreamer_main_context.push_thread_default()

        # Create main loop for this context
        self.gstreamer_main_loop = GLib.MainLoop.new(self.gstreamer_main_context, False)
        
        # Signal that initialization is complete
        self.gst_thread_started.set()

        print(f"GStreamer thread: MainLoop started in thread "
              f"{threading.current_thread().name}")
        
        # Run main loop (blocks until quit() is called)
        self.gstreamer_main_loop.run()

        # Cleanup after loop exits
        print(f"GStreamer thread: MainLoop finished in thread "
              f"{threading.current_thread().name}")
        self.gstreamer_main_context.pop_thread_default()

    def set_video_sink(self, index, sink):
        """
        Set video display container for a pipeline.
        
        Args:
            index (int): Pipeline index (0 or 1)
            sink (Gtk.Box): GTK container for video widget
        """
        if index == 0:
            GLib.idle_add(self.Pipeline0.set_sink, sink, 
                         context=self.gstreamer_main_context)
        else:
            GLib.idle_add(self.Pipeline1.set_sink, sink, 
                         context=self.gstreamer_main_context)
    
    def start_pipeline(self, index, command):
        """
        Start a pipeline with the given GStreamer command.
        
        Schedules pipeline start on the GStreamer thread.
        
        Args:
            index (int): Pipeline index (0 or 1)
            command (str): GStreamer pipeline description string
        """
        if index == 0:
            GLib.idle_add(self.Pipeline0.start, command, 
                         context=self.gstreamer_main_context)
        else:
            GLib.idle_add(self.Pipeline1.start, command, 
                         context=self.gstreamer_main_context)

    def stop_pipeline(self, index, on_stopped_callback=None):
        """
        Stop a pipeline asynchronously.
        
        Schedules pipeline stop on the GStreamer thread. The callback
        will be executed after the pipeline is fully stopped.
        
        Args:
            index (int): Pipeline index (0 or 1)
            on_stopped_callback (callable, optional): Function to call
                after pipeline is fully stopped
        """
        pipeline_to_stop = self.Pipeline0 if index == 0 else self.Pipeline1
        GLib.idle_add(pipeline_to_stop.stop, on_stopped_callback, 
                     context=self.gstreamer_main_context)

    def pipelines_finished(self):
        """
        Check if both pipelines are fully stopped.
        
        Returns:
            bool: True if both pipelines are None (fully cleaned up)
        """
        return (self.Pipeline0.pipeline is None and 
                self.Pipeline1.pipeline is None)

    def quit_gstreamer_main_loop(self):
        """
        Stop the GStreamer thread's main loop.
        
        This causes the GStreamer thread to exit. Should only be called
        during application shutdown after pipelines are stopped.
        """
        if self.gstreamer_main_loop and self.gstreamer_main_loop.is_running():
            self.gstreamer_main_loop.quit()


# ============================================================================
# MAIN EVENT HANDLER CLASS
# ============================================================================

class Handler:
    """
    Main event handler connecting UI to pipeline operations.
    
    This class serves as the central coordinator for the application,
    handling:
    - UI event callbacks (button clicks, combo box changes)
    - Camera detection and initialization
    - Pipeline lifecycle management
    - System performance monitoring
    - Automatic demo cycling
    - Application shutdown
    
    The Handler bridges GTK UI events to GStreamer pipeline operations,
    manages system resource monitoring, and coordinates the overall
    application state.
    
    Attributes:
        demoList (list): Available demo pipeline templates
        QProf (QProfProcess): Performance monitoring process
        pipelineCtrl (PipelineCtrl): Dual-pipeline controller
        MainWindow (Gtk.Window): Main application window
        aboutWindow (Gtk.Dialog): About dialog
        FPSRate0, FPSRate1 (Gtk.Label): FPS display labels
        CPU_load, GPU_load, DSP_load, MEM_load (Gtk.Label): Load labels
        CPU_temp, GPU_temp, MEM_temp (Gtk.Label): Temperature labels
        DrawArea1, DrawArea2 (Gtk.Box): Video display containers
        GraphDrawAreaTop, GraphDrawAreaBottom (Gtk.DrawingArea): Graph areas
        demo_selection0, demo_selection1 (Gtk.ComboBox): Pipeline selectors
        systemCameras (list): Detected cameras [(name, path, type), ...]
        sample_data (dict): Current system performance metrics
        CycleDemo0, CycleDemo1 (bool): Auto-cycling enabled flags
    """
    
    def __init__(self, display_fps_metrics=True):
        """
        Initialize the Handler and start background monitoring.
        
        Sets up demo list, initializes monitoring, and schedules periodic
        updates for system metrics and automatic demo cycling.
        
        Args:
            display_fps_metrics (bool): Whether to display FPS overlays
        """
        # Demo pipeline templates (placeholders replaced at runtime)
        self.demoList = [
            None,                  # Index 0: No demo selected
            CAMERA,                # Index 1: Raw camera feed
            POSE_DETECTION,        # Index 2: Pose estimation
            SEGMENTATION,          # Index 3: Segmentation
            CLASSIFICATION,        # Index 4: Image classification
            OBJECT_DETECTION,      # Index 5: Object detection
            DEPTH_SEGMENTATION,    # Index 6: Depth segmentation
        ]

        # Initialize monitoring and pipeline control
        self.QProf = QProfProcess()
        self.pipelineCtrl = PipelineCtrl()
        
        # UI element references (set by main script)
        self.MainWindowShown = False
        self.MainWindow = None
        self.aboutWindow = None
        self.FPSRate0 = None
        self.FPSRate1 = None
        self.CPU_load = None
        self.GPU_load = None
        self.DSP_load = None
        self.MEM_load = None
        self.CPU_temp = None
        self.GPU_temp = None
        self.MEM_temp = None
        self.TopBox = None
        self.DataGrid = None
        self.BottomBox = None
        self.DrawArea1 = None
        self.DrawArea2 = None
        self.AspectFrame1 = None
        self.AspectFrame2 = None
        self.GraphDrawAreaTop = None
        self.GraphDrawAreaBottom = None
        self.demo_selection0 = None
        self.demo_selection1 = None
        self.display_fps_metrics = display_fps_metrics
        
        # Camera and demo state
        self.systemCameras = []
        self.dualDemoRunning0 = False
        self.dualDemoRunning1 = False
        self.CycleDemo0 = False
        self.CycleDemo1 = False
        self.demoSelection0Cnt = 0
        self.demoSelection1Cnt = 0

        # System performance metrics
        # TODO: Protect with threading lock for thread-safe access
        self.sample_data = {
            CPU_UTIL_KEY: 0,
            MEM_UTIL_KEY: 0,
            GPU_UTIL_KEY: 0,
            DSP_UTIL_KEY: 0,
            CPU_THERMAL_KEY: 0,
            MEM_THERMAL_KEY: 0,
            GPU_THERMAL_KEY: 0,
            NPU_THERMAL_KEY: 0,
        }
        
        # Schedule periodic updates
        GLib.timeout_add(HW_SAMPLING_PERIOD_ms, self.update_sample_data)
        GLib.timeout_add(1000, self.automateDemo)  # Check every second

    def set_video_sink(self, index, sink):
        """
        Associate a GTK container with a pipeline for video display.
        
        Args:
            index (int): Pipeline index (0 or 1)
            sink (Gtk.Box): GTK container for video widget
        """
        self.pipelineCtrl.set_video_sink(index, sink)

    def update_camera_information(self):
        """
        Scan for cameras and enable pipeline selectors.
        
        Detects available cameras (USB and MIPI), stores their information,
        and enables the appropriate UI controls. Called after a delay on
        application startup to allow hardware initialization.
        
        Returns:
            int: GLib.SOURCE_REMOVE to indicate one-time execution
        """
        # Scan for connected cameras
        self.cameraCount = self.scan_for_connected_cameras()
        
        # Extract camera information (if available)
        self.cam1 = self.systemCameras[0][1] if self.cameraCount > 0 else None
        self.cam1Type = self.systemCameras[0][2] if self.cameraCount > 0 else None

        self.cam2 = self.systemCameras[1][1] if self.cameraCount > 1 else None
        self.cam2Type = self.systemCameras[1][2] if self.cameraCount > 1 else None

        # Enable pipeline selectors for available cameras
        if self.cam1:
            self.demo_selection0.set_sensitive(True)

        if self.cam2:
            self.demo_selection1.set_sensitive(True)

        print(f"Using CAM1: {self.cam1}")
        print(f"Using CAM2: {self.cam2}")
        
        # Close the "scanning for cameras" dialog
        self.close_dialog(self)
        return GLib.SOURCE_REMOVE
        
    def _probe_mipi_camera(self, camera_index, timeout_s=MIPI_CSI_CAMERA_SCAN_TIMEOUT):
        """
        Probe for MIPI camera using GStreamer API.
        
        Attempts to create and configure a qtiqmmfsrc element for the
        specified camera index, then tries to set it to PAUSED state.
        If successful, the camera is detected and available.
        
        This method is more reliable than command-line probing as it
        directly uses the GStreamer API and properly handles async
        state changes.
        
        Args:
            camera_index (int): MIPI camera index to probe (typically 0 or 1)
            timeout_s (float): Maximum time to wait for camera initialization
            
        Returns:
            bool: True if camera is detected and accessible, False otherwise
        """
        print(f"Probing for MIPI camera index: {camera_index} using GStreamer API...")
        
        # Create MIPI camera source element
        src = Gst.ElementFactory.make("qtiqmmfsrc", f"mipi-probe-{camera_index}")
        if not src:
            print("  Error: Failed to create qtiqmmfsrc element. "
                  "Is the plugin installed?")
            return False

        # Set camera index property
        try:
            src.set_property("camera", camera_index)
        except TypeError:
            print(f"  Error: Could not set 'camera' property on qtiqmmfsrc. "
                  f"Is the element correct?")
            return False

        # Create probe pipeline with fakesink
        pipeline = Gst.Pipeline.new(f"mipi-probe-pipeline-{camera_index}")
        sink = Gst.ElementFactory.make("fakesink", f"mipi-probe-sink-{camera_index}")
        if not sink:
            print("  Error: Failed to create fakesink element.")
            src.set_state(Gst.State.NULL)
            return False

        # Link elements
        pipeline.add(src)
        pipeline.add(sink)
        if not src.link(sink):
            print(f"  Error: Could not link qtiqmmfsrc to fakesink for camera "
                  f"{camera_index}.")
            pipeline.set_state(Gst.State.NULL)
            return False

        # Attempt to set to PAUSED (acquires camera resource)
        state_change_return = pipeline.set_state(Gst.State.PAUSED)

        found = False
        
        # Check state change result
        if (state_change_return == Gst.StateChangeReturn.SUCCESS or 
            state_change_return == Gst.StateChangeReturn.NO_PREROLL):
            # Camera found and acquired
            print(f"  Success: MIPI camera {camera_index} found (state change "
                  f"result: {state_change_return.value_nick}).")
            found = True
        elif state_change_return == Gst.StateChangeReturn.ASYNC:
            # State change is asynchronous, wait for completion
            _, current_state, _ = pipeline.get_state(timeout_s * Gst.SECOND)
            if current_state == Gst.State.PAUSED:
                print(f"  Success: MIPI camera {camera_index} found (state change "
                      f"was asynchronous).")
                found = True
            else:
                print(f"  Failure: MIPI camera {camera_index} timed out or failed "
                      f"to reach PAUSED state (final state: {current_state.value_nick}).")
                found = False
        else:  # FAILURE
            print(f"  Failure: MIPI camera {camera_index} could not be opened "
                  f"(state change failed with: {state_change_return.value_nick}).")
            found = False

        # Always clean up probe pipeline
        pipeline.set_state(Gst.State.NULL)
        
        return found

    def scan_for_connected_cameras(self):
        """
        Scan for all connected cameras (USB and MIPI).
        
        Detects cameras through two methods:
        1. USB cameras: via /dev/v4l/by-id symlinks
        2. MIPI cameras: via GStreamer probing
        
        Populates self.systemCameras with tuples of (name, path, type).
        
        Returns:
            int: Total number of cameras detected
        """
        # ===== Scan for USB Cameras =====
        try:
            usb_cameras_path = pathlib.Path("/dev/v4l/by-id")
            print(f"Scanning for USB cameras...")
            
            if not usb_cameras_path.exists():
                print("Warning: no USB cameras found. "
                      "Please examine your USB camera connections.")
            else:
                # List all devices in /dev/v4l/by-id
                output = subprocess.check_output(["ls", "/dev/v4l/by-id"])
                device_id = -1
                
                for device_info in output.decode().splitlines():
                    # Only use video-index0 (primary video device)
                    if "video-index0" in device_info:
                        device_id = device_id + 1
                        self.systemCameras.append(
                            ("USB CAM" + str(device_id), 
                             "/dev/v4l/by-id/" + device_info, 
                             "usb")
                        )
        except Exception as e:
            print(f"Error scanning for USB cameras: {e}")

        # ===== Scan for MIPI Cameras =====
        try:
            print(f"Scanning for MIPI-CSI cameras...")
            
            # Probe camera indices 0 and 1
            for camIndex in range(0, 2):
                try:
                    if self._probe_mipi_camera(camIndex, MIPI_CSI_CAMERA_SCAN_TIMEOUT):
                        self.systemCameras.append(
                            ("MIPI CAM" + str(camIndex), 
                             "camera=" + str(camIndex), 
                             "mipi")
                        )
                except Exception as e:
                    print(f"MIPI camera={camIndex} failed: {e}")
        except Exception as e:
            print(f"Error scanning for MIPI-CSI cameras: {e}")
            
        return len(self.systemCameras)

    '''def update_temps(self):
        """
        Update temperature readings from system sensors.
        
        Reads CPU, GPU, and memory temperatures and updates both the
        sample_data dictionary and the UI labels. Runs in a worker
        thread to avoid blocking the UI.
        
        Returns:
            int: GLib.SOURCE_REMOVE to indicate one-time execution
        """
        if not self.sample_data:
            return GLib.SOURCE_REMOVE
        
        # Read temperature sensors
        cpu_temp, gpu_temp, mem_temp = get_cpu_gpu_mem_temps()

        # Update sample data and UI labels
        self.sample_data[CPU_THERMAL_KEY] = cpu_temp
        if cpu_temp is not None:
            GLib.idle_add(self.CPU_temp.set_text, "{:6.2f}".format(cpu_temp))
        
        self.sample_data[GPU_THERMAL_KEY] = gpu_temp
        if gpu_temp is not None:
            GLib.idle_add(self.GPU_temp.set_text, "{:6.2f}".format(gpu_temp))
        
        self.sample_data[MEM_THERMAL_KEY] = mem_temp
        if mem_temp is not None:
            GLib.idle_add(self.MEM_temp.set_text, "{:6.2f}".format(mem_temp))

        return GLib.SOURCE_REMOVE'''


    def update_temps(self):
        """
        Update temperature readings from system sensors.
        """
        if not self.sample_data:
            return GLib.SOURCE_REMOVE
        
        # Read temperature sensors
        cpu_temp, gpu_temp, mem_temp, npu_temp = get_cpu_gpu_mem_npu_temps()

        # Update sample data and UI labels
        self.sample_data[CPU_THERMAL_KEY] = cpu_temp
        if cpu_temp is not None:
            GLib.idle_add(self.CPU_temp.set_text, "{:6.2f}".format(cpu_temp))
        
        self.sample_data[GPU_THERMAL_KEY] = gpu_temp
        if gpu_temp is not None:
            GLib.idle_add(self.GPU_temp.set_text, "{:6.2f}".format(gpu_temp))
        
        self.sample_data[MEM_THERMAL_KEY] = mem_temp
        if mem_temp is not None:
            GLib.idle_add(self.MEM_temp.set_text, "{:6.2f}".format(mem_temp))
        
        # ← ADD NPU TEMPERATURE
        self.sample_data[NPU_THERMAL_KEY] = npu_temp
        # Note: You'll need to add NPU_temp label to your UI if you want to display it

        return GLib.SOURCE_REMOVE


    def update_loads(self):
        """
        Update system utilization metrics.
        
        Queries CPU, GPU, memory, and DSP utilization from QProf and
        updates both the sample_data dictionary and the UI labels.
        Runs in a worker thread to avoid blocking the UI.
        
        Returns:
            int: GLib.SOURCE_REMOVE to indicate one-time execution
        """
        if not self.sample_data:
            return GLib.SOURCE_REMOVE

        # Query utilization metrics from QProf
        cpu_util, gpu_util, mem_util, dsp_util = (
            self.QProf.get_cpu_usage_pct(),
            self.QProf.get_gpu_usage_pct(),
            self.QProf.get_memory_usage_pct(),
            self.QProf.get_dsp_usage_pct(),
        )
        
        # Update sample data
        self.sample_data[CPU_UTIL_KEY] = cpu_util
        self.sample_data[GPU_UTIL_KEY] = gpu_util
        self.sample_data[MEM_UTIL_KEY] = mem_util
        self.sample_data[DSP_UTIL_KEY] = dsp_util
        
        # Schedule UI updates on main thread
        GLib.idle_add(self.CPU_load.set_text, "{:6.2f}".format(cpu_util))
        GLib.idle_add(self.GPU_load.set_text, "{:6.2f}".format(gpu_util))
        GLib.idle_add(self.MEM_load.set_text, "{:6.2f}".format(mem_util))
        GLib.idle_add(self.DSP_load.set_text, "{:6.2f}".format(dsp_util))
        
        return GLib.SOURCE_REMOVE

    def update_sample_data(self):
        """
        Periodic callback to update all system metrics.
        
        Spawns worker threads for temperature and load sampling to avoid
        blocking the UI thread with I/O operations. Each worker thread
        schedules its own UI updates.
        
        Returns:
            int: GLib.SOURCE_CONTINUE to keep periodic updates running
        """
        # Run blocking I/O in separate threads to avoid freezing UI
        threading.Thread(target=self.update_temps, daemon=True).start()
        threading.Thread(target=self.update_loads, daemon=True).start()
        return GLib.SOURCE_CONTINUE

    def close_about(self, *args):
        """
        Close the About dialog.
        
        Args:
            *args: GTK signal arguments (unused)
        """
        if self.aboutWindow:
            self.aboutWindow.hide()

    def open_about(self, *args):
        """
        Open the About dialog.
        
        Args:
            *args: GTK signal arguments (unused)
        """
        if self.aboutWindow:
            self.aboutWindow.set_transient_for(self.MainWindow)
            self.aboutWindow.run()

    def on_mainWindow_destroy(self, *args):
        """
        Handle application exit signal.
        
        Initiates graceful shutdown sequence:
        1. Close performance monitoring
        2. Stop both pipelines asynchronously
        3. Schedule polling for cleanup completion
        4. Exit GTK main loop after cleanup
        
        This method is called by GTK when the window is closed or the
        application receives a termination signal.
        
        Args:
            *args: GTK signal arguments
        """
        print("Shutdown initiated...")
        
        # Close performance monitoring
        if self.QProf is not None:
            self.QProf.Close()

        # Asynchronously stop both pipelines
        # Callbacks not needed here as we poll for completion
        self.pipelineCtrl.stop_pipeline(0)
        self.pipelineCtrl.stop_pipeline(1)

        # Schedule polling to wait for pipeline cleanup before exit
        GLib.timeout_add(QUIT_CLEANUP_DELAY_ms, self.quit_application, *args)

    def quit_application(self, *args):
        """
        Poll for pipeline cleanup completion and exit when ready.
        
        This callback is repeatedly called until both pipelines are fully
        stopped, then it quits the GStreamer thread, waits for background
        threads to join, and exits the GTK main loop.
        
        Args:
            *args: GTK signal arguments
            
        Returns:
            int: GLib.SOURCE_CONTINUE to keep polling, or
                 GLib.SOURCE_REMOVE when cleanup is complete
        """
        # Check if both pipelines have finished cleanup
        if self.pipelineCtrl.pipelines_finished():
            print("All pipelines cleaned up. Quitting GStreamer loop.")
            self.pipelineCtrl.quit_gstreamer_main_loop()

            print("Waiting for background threads to join...")
            
            # Wait for QProf thread to exit
            if self.QProf and self.QProf.is_alive():
                self.QProf.join(timeout=2.0)
            
            # Wait for GStreamer thread to exit
            if self.pipelineCtrl.gst_thread and self.pipelineCtrl.gst_thread.is_alive():
                self.pipelineCtrl.gst_thread.join(timeout=2.0)

            print("Exiting GTK main loop.")
            Gtk.main_quit(*args)
            return GLib.SOURCE_REMOVE  # Stop polling
        else:
            print("Waiting for pipelines to finish cleanup...")
            return GLib.SOURCE_CONTINUE  # Keep polling

    def close_dialog(self, *args):
        """
        Close the camera scanning dialog.
        
        Args:
            *args: GTK signal arguments (unused)
            
        Returns:
            int: GLib.SOURCE_REMOVE to indicate one-time execution
        """
        if self.dialogWindow:
            self.dialogWindow.hide()
        return GLib.SOURCE_REMOVE

    def show_message(self):
        """
        Show the camera scanning dialog.
        
        Displays a modal dialog while cameras are being detected.
        
        Returns:
            int: GLib.SOURCE_REMOVE to indicate one-time execution
        """
        if self.dialogWindow:
            self.dialogWindow.set_transient_for(self.MainWindow)
            self.dialogWindow.show_all()
        return GLib.SOURCE_REMOVE

    def on_mainWindow_show(self, *args):
        """
        Handle main window show event.
        
        Called when the main window is first displayed. Shows the camera
        scanning dialog and schedules camera detection after a delay to
        allow hardware initialization.
        
        Args:
            *args: GTK signal arguments (unused)
        """
        if not self.MainWindowShown:
            self.MainWindowShown = True
            # Show scanning dialog
            GLib.idle_add(self.show_message)
            # Schedule camera scan after delay
            GLib.timeout_add(CAMERA_SCAN_DELAY_ms, self.update_camera_information)

    def _modify_command_pipeline(self, command, stream_index, inject_health_signal=True):
        """
        Modify pipeline template by replacing placeholders with runtime values.
        
        Processes a pipeline template string, replacing placeholders with:
        - Display sink configuration (single or dual window)
        - Camera source element (USB v4l2src or MIPI qtiqmmfsrc)
        - Health monitoring element (optional identity for debugging)
        
        Placeholders:
        - <SINGLE_DISPLAY>: Single window video sink
        - <DUAL_DISPLAY>: Dual window video sink
        - <DATA_SRC>: Camera source element
        
        Args:
            command (str): Pipeline template string
            stream_index (int): Pipeline index (0 or 1)
            inject_health_signal (bool): Whether to add health monitoring element
            
        Returns:
            str: Modified pipeline string ready for GStreamer
        """
        # Configure FPS display overlay if enabled
        displaysink_text = (
            "fpsdisplaysink text-overlay=true video-sink="
            if self.display_fps_metrics
            else ""
        )

        # Replace display sink placeholders
        # NOTE: fpsdisplaysink requires video-sink property to be wrapped in quotes
        command = command.replace(
            "<SINGLE_DISPLAY>",
            f'{displaysink_text}{DEFAULT_LEFT_WINDOW}',
        )
        command = command.replace(
            "<DUAL_DISPLAY>",
            f'{displaysink_text}{DEFAULT_DUAL_WINDOW}',
        )

        # Optional health monitoring element
        health_monitor_addin = (
            " ! " + PIPELINE_HEALTH_SIGNAL if inject_health_signal else ""
        )
        
        # Replace camera source placeholder based on pipeline index
        if stream_index == 0 and self.cam1 is not None:
            if self.cam1Type == "usb":
                command = command.replace(
                    "<DATA_SRC>",
                    f"v4l2src device={self.cam1} name=videosource" + health_monitor_addin
                )
            elif self.cam1Type == "mipi":
                command = command.replace(
                    "<DATA_SRC>",
                    f"qtiqmmfsrc {self.cam1} name=videosource" + health_monitor_addin
                )
        elif self.cam2 is not None:
            if self.cam2Type == "usb":
                command = command.replace(
                    "<DATA_SRC>",
                    f"v4l2src device={self.cam2} name=videosource" + health_monitor_addin
                )
            elif self.cam2Type == "mipi":
                command = command.replace(
                    "<DATA_SRC>",
                    f"qtiqmmfsrc {self.cam2} name=videosource" + health_monitor_addin
                )
        else:
            # No camera available, use test source
            command = command.replace(
                "<DATA_SRC>",
                f"videotestsrc name=videosource" + health_monitor_addin
            )
            
        return command

    '''def SwitchPipeline0(self, combo):
        """
        Switch pipeline 0 to selected demo.
        
        Stops the current pipeline and starts the newly selected one.
        Uses a callback to ensure the old pipeline is fully stopped
        before starting the new one, preventing resource conflicts.
        
        Args:
            combo (Gtk.ComboBox): Demo selection combo box
        """
        index = combo.get_active()

        def start_new_pipeline():
            """Callback executed after old pipeline is stopped."""
            if index > 0:  # Demo selected (not "None")
                self.CycleDemo0 = True
                
                # Get pipeline template and modify it
                command = self.demoList[index][:]
                command = self._modify_command_pipeline(command, 0)
                
                print(f"Starting pipeline 0: {command}")
                self.pipelineCtrl.start_pipeline(0, command)
                
                # Set background to black (video is displaying)
                self.DrawArea1.override_background_color(
                    Gtk.StateType.NORMAL, Gdk.RGBA(0, 0, 0, 1)
                )
            else:  # "None" selected
                self.CycleDemo0 = False
                print("Pipeline 0 set to None.")
                
                # Set background to transparent (no video)
                self.DrawArea1.override_background_color(
                    Gtk.StateType.NORMAL, Gdk.RGBA(0, 0, 0, 0)
                )

        # Stop current pipeline, then start new one in callback
        # This prevents race conditions and resource conflicts
        self.pipelineCtrl.stop_pipeline(0, on_stopped_callback=start_new_pipeline)

    def SwitchPipeline1(self, combo):
        """
        Switch pipeline 1 to selected demo.
        
        Identical to SwitchPipeline0 but for the second camera/pipeline.
        
        Args:
            combo (Gtk.ComboBox): Demo selection combo box
        """
        index = combo.get_active()

        def start_new_pipeline():
            """Callback executed after old pipeline is stopped."""
            if index > 0:  # Demo selected (not "None")
                self.CycleDemo1 = True
                
                # Get pipeline template and modify it
                command = self.demoList[index][:]
                command = self._modify_command_pipeline(command, 1)
                
                print(f"Starting pipeline 1: {command}")
                self.pipelineCtrl.start_pipeline(1, command)
                
                # Set background to black (video is displaying)
                self.DrawArea2.override_background_color(
                    Gtk.StateType.NORMAL, Gdk.RGBA(0, 0, 0, 1)
                )
            else:  # "None" selected
                self.CycleDemo1 = False
                print("Pipeline 1 set to None.")
                
                # Set background to transparent (no video)
                self.DrawArea2.override_background_color(
                    Gtk.StateType.NORMAL, Gdk.RGBA(0, 0, 0, 0)
                )

        # Stop current pipeline, then start new one in callback
        self.pipelineCtrl.stop_pipeline(1, on_stopped_callback=start_new_pipeline)'''

    
    def SwitchPipeline0(self, combo):
        """
        Switch pipeline 0 to selected demo.
        """
        index = combo.get_active()

        def start_new_pipeline():
            """Callback executed after old pipeline is stopped."""
            if index > 0:  # Demo selected (not "None")
                self.CycleDemo0 = True

                # Set telemetry flag based on demo index
                # Indices 1, 3, 6 don't send telemetry (Camera, Segmentation, Depth Segmentation)
                # Indices 2, 4, 5 do send telemetry (Pose, Classification, Object Detection)
                if hasattr(self, 'vai_manager'):
                    self.vai_manager.demo0_index = index

                # Get pipeline template and modify it
                command = self.demoList[index][:]
                command = self._modify_command_pipeline(command, 0)

                print(f"Starting pipeline 0: {command}")
                self.pipelineCtrl.start_pipeline(0, command)

                # Set background to black (video is displaying)
                self.DrawArea1.override_background_color(
                    Gtk.StateType.NORMAL, Gdk.RGBA(0, 0, 0, 1)
                )
            else:  # "None" selected
                self.CycleDemo0 = False
                # Disable telemetry when no demo is running
                if hasattr(self, 'vai_manager'):
                    self.vai_manager.demo0_index = index
                print("Pipeline 0 set to None.")

                # Set background to transparent (no video)
                self.DrawArea1.override_background_color(
                    Gtk.StateType.NORMAL, Gdk.RGBA(0, 0, 0, 0)
                )

        # Stop current pipeline, then start new one in callback
        self.pipelineCtrl.stop_pipeline(0, on_stopped_callback=start_new_pipeline)


    def SwitchPipeline1(self, combo):
        """
        Switch pipeline 1 to selected demo.
        """
        index = combo.get_active()

        def start_new_pipeline():
            """Callback executed after old pipeline is stopped."""
            if index > 0:  # Demo selected (not "None")
                self.CycleDemo1 = True
                
                # Set telemetry flag based on demo index
                if hasattr(self, 'vai_manager'):
                    self.vai_manager.demo1_index = index
                
                # Get pipeline template and modify it
                command = self.demoList[index][:]
                command = self._modify_command_pipeline(command, 1)
                
                print(f"Starting pipeline 1: {command}")
                self.pipelineCtrl.start_pipeline(1, command)
                
                # Set background to black (video is displaying)
                self.DrawArea2.override_background_color(
                    Gtk.StateType.NORMAL, Gdk.RGBA(0, 0, 0, 1)
                )
            else:  # "None" selected
                self.CycleDemo1 = False
                # Disable telemetry when no demo is running
                if hasattr(self, 'vai_manager'):
                    self.vai_manager.demo1_index = index
                print("Pipeline 1 set to None.")
                
                # Set background to transparent (no video)
                self.DrawArea2.override_background_color(
                    Gtk.StateType.NORMAL, Gdk.RGBA(0, 0, 0, 0)
                )

        # Stop current pipeline, then start new one in callback
        self.pipelineCtrl.stop_pipeline(1, on_stopped_callback=start_new_pipeline)


    def demo0_selection_changed_cb(self, combo):
        """
        Signal handler for demo selection combo box 0.
        
        Called when user changes pipeline 0 selection. Runs on GTK main
        thread, so it's safe to call non-blocking operations directly.
        
        Args:
            combo (Gtk.ComboBox): The combo box that triggered the signal
        """
        self.SwitchPipeline0(combo)

    def demo1_selection_changed_cb(self, combo):
        """
        Signal handler for demo selection combo box 1.
        
        Called when user changes pipeline 1 selection. Runs on GTK main
        thread, so it's safe to call non-blocking operations directly.
        
        Args:
            combo (Gtk.ComboBox): The combo box that triggered the signal
        """
        self.SwitchPipeline1(combo)

    def automateDemo(self):
        """
        Automatic demo cycling logic.
        
        If auto-cycling is enabled for a pipeline (CycleDemo0/1 = True),
        this method automatically switches to the next demo after a fixed
        interval. The two pipelines are staggered to avoid switching
        simultaneously, which could cause resource contention.
        
        Timing:
        - Demos switch every AUTOMATIC_DEMO_SWITCH_s seconds
        - Pipeline 1 is offset by half the interval from Pipeline 0
        - Demos cycle through indices 1 to demoSelectionCnt-1
        
        Returns:
            int: GLib.SOURCE_CONTINUE to keep periodic updates running
        """
        # Verify UI elements exist
        if not self.demo_selection0 or not self.demo_selection1:
            return
        
        # Determine if auto-cycling is enabled for each pipeline
        cycleDemo0 = (self.CycleDemo0 and self.demoSelection0Cnt > 0)
        cycleDemo1 = (self.CycleDemo1 and self.demoSelection1Cnt > 0)
        
        # Reset intervals if cycling disabled
        if not cycleDemo0:
            self.demo0Interval = 0
            self.demo0RunningIndex = 1
        
        if not cycleDemo1:
            self.demo1Interval = 0
            self.demo1RunningIndex = 1

        # Handle Pipeline 0 auto-cycling
        if cycleDemo0:
            if self.demo0Interval >= AUTOMATIC_DEMO_SWITCH_s:
                self.demo0Interval = 0

                # Stagger Pipeline 1 to avoid simultaneous switches
                self.demo1Interval = int(AUTOMATIC_DEMO_SWITCH_s / 2)

                # Advance to next demo
                self.demo0RunningIndex = self.demo0RunningIndex + 1

                # Wrap around if at end of list
                if self.demo0RunningIndex >= self.demoSelection0Cnt:
                    self.demo0RunningIndex = 1
                
                # Trigger pipeline switch
                self.demo_selection0.set_active(self.demo0RunningIndex)
            else:
                self.demo0Interval = self.demo0Interval + 1

        # Handle Pipeline 1 auto-cycling
        if cycleDemo1:
            if self.demo1Interval >= AUTOMATIC_DEMO_SWITCH_s:
                self.demo1Interval = 0

                # Force Pipeline 1 to run a different demo than Pipeline 0
                if self.demo0RunningIndex >= 0:
                    self.demo1RunningIndex = self.demo0RunningIndex + 1
                else:
                    self.demo1RunningIndex = self.demo1RunningIndex + 1

                # Wrap around if at end of list
                if self.demo1RunningIndex >= self.demoSelection1Cnt:
                    self.demo1RunningIndex = 1

                # Trigger pipeline switch
                self.demo_selection1.set_active(self.demo1RunningIndex)
            else:
                self.demo1Interval = self.demo1Interval + 1

        return GLib.SOURCE_CONTINUE
