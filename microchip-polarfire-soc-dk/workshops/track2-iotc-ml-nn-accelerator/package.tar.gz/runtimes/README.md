# Runtime ELFs (Required)

Place prebuilt NN runtime binaries here:

- `tinyml_nn.no_accel.elf` (software path)
- `tinyml_nn.accel.elf` (hardware-accelerated path)

These names are referenced by `src/ml_runner.py`.
