# Runtime ELFs

Place the prebuilt runtime binaries here:

- `tinyml_complex.no_accel.elf`
- `tinyml_complex.accel.elf`

These are required by `create-package.sh`.
