# Runtime Binaries

Place prebuilt Tiny-ML binaries here before packaging:

- `invert_and_threshold.no_accel.elf`
- `invert_and_threshold.accel.elf`

These are produced by SmartHLS in:

`script_support/additional_configurations/smarthls/invert_and_threshold/hls_output/`

Quickstart flow does not require SmartHLS if the binaries are already included in the package.
